import React, { useState } from 'react';
import styled from 'styled-components';
import { X } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';

const Overlay = styled.div`
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.85);
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: center;
`;

const Modal = styled.div`
    background: #313338;
    width: 100%;
    max-width: 500px;
    border-radius: 8px;
    overflow: hidden;
    position: relative;
    padding: 24px;
    color: var(--text-main);
`;

const CloseBtn = styled.button`
    position: absolute;
    top: 16px; right: 16px;
    background: transparent;
    border: none;
    color: #b5bac1;
    cursor: pointer;
    &:hover { color: #fff; }
`;

const Field = styled.div`
    margin-bottom: 20px;
`;

const Label = styled.label`
    display: block;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    color: #b5bac1;
    margin-bottom: 8px;
`;

const Input = styled.input`
    width: 100%;
    background: #1e1f22;
    border: none;
    padding: 10px;
    border-radius: 4px;
    color: #fff;
    outline: none;
    box-sizing: border-box;
`;

const ColorInput = styled.input`
    width: 100%;
    height: 40px;
    border: none;
    background: transparent;
    cursor: pointer;
`;

export const SettingsModal = ({ isOpen, onClose }) => {
    const { user, updateUser } = useAuth();
    const { theme, updateTheme } = useTheme();

    if (!isOpen) return null;

    return (
        <Overlay onClick={onClose}>
            <Modal onClick={e => e.stopPropagation()}>
                <CloseBtn onClick={onClose}><X /></CloseBtn>
                <h2>User Settings</h2>
                
                <Field>
                    <Label>Username</Label>
                    <Input 
                        value={user.name} 
                        onChange={(e) => updateUser({ name: e.target.value })}
                        placeholder="Type a username..."
                    />
                </Field>

                <Field>
                    <Label>Avatar URL</Label>
                    <Input 
                        value={user.avatar} 
                        onChange={(e) => updateUser({ avatar: e.target.value })}
                        placeholder="Image URL..."
                    />
                </Field>

                <Field>
                    <Label>Accent Color</Label>
                    <ColorInput 
                        type="color" 
                        value={theme.accentColor} 
                        onChange={(e) => updateTheme({ accentColor: e.target.value })}
                    />
                </Field>

                <Field>
                    <Label>Sidebar Background</Label>
                    <ColorInput 
                        type="color" 
                        value={theme.sidebarBg} 
                        onChange={(e) => updateTheme({ sidebarBg: e.target.value })}
                    />
                </Field>
            </Modal>
        </Overlay>
    );
};
